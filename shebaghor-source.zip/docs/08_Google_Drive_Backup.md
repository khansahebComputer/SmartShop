# Google Drive ব্যাকআপ — সেটআপ ও সীমাবদ্ধতা

এডমিন → সেটিংস → "☁️ Google Drive ব্যাকআপ" কার্ড। ব্যাকআপ JSON সরাসরি Google Drive-এর **appDataFolder**-এ (অ্যাপের জন্য সংরক্ষিত লুকানো ফোল্ডার) আপলোড হয়; অন্য কোনো অ্যাপ বা ব্যবহারকারী তা দেখতে পারে না। স্কোপ: `https://www.googleapis.com/auth/drive.appdata` — `drive.file` নয়; রিস্ক সর্বনিম্ন।

## Console সেটআপ (একবারের কাজ, ~৫ মিনিট)
1. <https://console.cloud.google.com> → প্রজেক্ট বাছা/তৈরি → **APIs & Services → Library → Google Drive API → Enable**।
2. **OAuth consent screen** → External → App name "সেবাঘর ব্যাকআপ" → support email → scopes-এ কিছু যোগ করার দরকার নেই (token request-এ scope পাঠানো হয়) → Save।
3. **Credentials → Create credentials → OAuth client ID** → Application type: **Web application**।
4. **Authorized JavaScript origins**: যেসব origin থেকে সাইট খুলবে — যেমন `http://localhost:8080`, প্রোডাকশন ডোমেইন (GitHub Pages হলে `https://<user>.github.io`, কাস্টম ডোমেইন হলে সেটি)। এখানে `*.e2b.app` প্রিভিউ URL-ও চাইলে যোগ করুন।
5. Client ID (`…apps.googleusercontent.com`) কপি করে হয় `assets/js/config.js`-এর `GOOGLE_DRIVE_CLIENT_ID`-এ বসান (commit হয়ে যায় — এটি public identifier, গোপন নয়), অথবা এডমিন কার্ডের বক্সে পেস্ট করে সেভ করুন (শুধু এই ব্রাউজারে, localStorage — commit হয় না)।
6. এডমিন → সেটিংস → "ড্রাইভে সংযুক্ত করুন" → Google সাইন-ইন → অনুমতি দিন (drive.appdata — শুধু অ্যাপের নিজের ফোল্ডার)।

## কী হয় / কী হয় না
- "ড্রাইভে ব্যাকআপ নিন" → `shebaghor-backup-YYYYMMDD-HHmm.json` appDataFolder-এ আপলোড (multipart)। সাপ্তাহিক করে রাখাই লক্ষ্য।
- "⬇️ আনুন" → ব্যাকআপ JSON ডাউনলোড। **রিস্টোর in-app নেই ইচ্ছাকৃতভাবে** — আসল রিস্টোর অর্ডার-পরিবারের সব সারি মুছে প্রতিস্থাপন করে, তাই সেটি ইচ্ছাকৃত হাতে চালানোর জিনিস: ডাউনলোড করে `tools/restore-backup.sql` (দেখুন `docs/07_Release_Runbook.md`), অথবা `tools/backup-to-sql.py` → hosted SQL editor।
- "সর্বশেষ ৩টি রেখে বাকি মুছুন" → শুধু ম্যানুয়াল, কনফার্মেশনসহ; কখনো স্বয়ংক্রিয় নয়। পুরোনো ব্যাকআপ নতুনটি সফল হওয়ার পরই মুছুন।
- CSP: `admin.html`-এ কেবল `accounts.google.com` / `www.googleapis.com` যোগ করা হয়েছে (script-src, connect-src, frame-src)। অন্য পেজে GIS নেই।
- টোকেন মেমরিতে থাকে, স্টোরেজে সেভ হয় না; ব্রাউজার রিলোড = আবার "সংযুক্ত করুন"।
- ব্যর্থতা: ইন্টারনেট না থাকলে Drive কাজ করবে না — JSON ডাউনলোড (পুরনো পথ) ব্যবহার করুন। `drive.appdata` ফোল্ডার খালি/অদৃশ্য হলে এটিই অ্যাপের নিয়ম।
