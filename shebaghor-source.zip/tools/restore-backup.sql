-- ============================================================================
-- সেবাঘর — ডিজস্টার রিস্টোর (backup JSON → orders/items/payments/events/files/proofs)
-- ব্যবহার:
--   sudo -u postgres psql -d shebaghor \
--     -v backup_file='/absolute/path/shebaghor-backup-YYYY-MM-DD.json' \
--     -f tools/restore-backup.sql
-- সাবধান: orders পরিবারের সব সারি মুছে backup দিয়ে প্রতিস্থাপন করে।
-- profiles (ব্যবহারকারী অ্যাকাউন্ট) ও services/shop_settings ছোঁয় না —
-- নতুন প্রজেক্টে schema.sql + seed.sql + প্রথম admin সাইনআপের পর ব্যবহার করুন।
-- backup-এ ফাইলের আসল বাইট (PDF/ছবি) নেই — শুধু মেটাডেটা।
-- সব delete/insert একটি লেনদেনে; ব্যর্থ হলে ON_ERROR_STOP দিয়ে প্রিদ রোলব্যাক।
-- ============================================================================
\set ON_ERROR_STOP on

begin;

-- ---------- বৈধতা যাচাই (ব্যর্থ হলে সম্পূর্ণ লেনদেন রোলব্যাক — ডেটা মুছবে না) ----------
-- নোট: empty অ্যারে (খালি দোকান) বৈধ — শুধু 'array' টাইপ ও উপস্থিতি যাচাই হয়।
-- psql ভ্যারিয়েবল ডলার-কোটেড ব্লকের ভেতরে সাবস্টিটিউট হয় না, তাই প্রথমে টেম্প টেবিলে JSON রাখা হয়।
create temporary table _backup_src(j jsonb);
insert into _backup_src values (pg_read_file(:'backup_file')::jsonb);

DO $$
DECLARE
  j jsonb := (select j from _backup_src);
BEGIN
  IF jsonb_typeof(j) IS DISTINCT FROM 'object' THEN
    RAISE EXCEPTION 'backup JSON অবজেক্ট নয় (corrupted?) — লেনদেন বাতিল, কোনো ডেটা মোছা হয়নি।';
  END IF;
  IF jsonb_typeof(j -> 'tables' -> 'orders') IS DISTINCT FROM 'array' THEN
    RAISE EXCEPTION 'backup JSON-এ tables.orders অ্যারে নেই (বা ফাইলটি corrupted/পুরনো ভার্সন) — লেনদেন বাতিল, কোনো ডেটা মোছা হয়নি।';
  END IF;
  IF jsonb_typeof(j -> 'tables' -> 'order_items') IS DISTINCT FROM 'array' THEN
    RAISE EXCEPTION 'backup JSON-এ tables.order_items অ্যারে নেই — অর্ডারগুলো আইটেম ছাড়া রিস্টোর হতে পারত; লেনদেন বাতিল, কোনো ডেটা মোছা হয়নি।';
  END IF;
END $$;

-- ---------- FK-safe wipe ----------
delete from public.design_proofs;
delete from public.order_events;
delete from public.order_files;
delete from public.order_items;
delete from public.payments;
delete from public.orders;

-- ---------------- orders ----------------
with bk as (select pg_read_file(:'backup_file')::jsonb as j)
insert into public.orders(id, order_date, token, status, subtotal, discount, total, paid,
                          payment_method, payment_status, pickup_slot, notes, rework,
                          guest_name, guest_phone, customer_id, created_by, created_at, updated_at)
select (r->>'id')::uuid, (r->>'order_date')::date, (r->>'token')::integer,
       (r->>'status')::order_status, (r->>'subtotal')::integer,
       coalesce((r->>'discount')::integer, 0), (r->>'total')::integer,
       coalesce((r->>'paid')::integer, 0),
       (r->>'payment_method')::payment_method, (r->>'payment_status')::payment_status,
       r->>'pickup_slot', r->>'notes', coalesce((r->>'rework')::boolean, false),
       r->>'guest_name', r->>'guest_phone',
       nullif(r->>'customer_id','')::uuid, nullif(r->>'created_by','')::uuid,
       (r->>'created_at')::timestamptz,
       coalesce((r->>'updated_at')::timestamptz, (r->>'created_at')::timestamptz, now())
from bk, jsonb_array_elements(bk.j->'tables'->'orders') r;

-- ---------------- order_items ----------------
with bk as (select pg_read_file(:'backup_file')::jsonb as j)
insert into public.order_items(id, order_id, service_id, name_snapshot, unit_snapshot, qty, unit_price, options)
select coalesce(nullif(r->>'id','')::uuid, gen_random_uuid()),
       (r->>'order_id')::uuid,
       (case when exists (select 1 from public.services s where s.id = nullif(r->>'service_id','')::uuid)
             then nullif(r->>'service_id','')::uuid else null end),
       r->>'name_snapshot', r->>'unit_snapshot',
       (r->>'qty')::numeric, (r->>'unit_price')::integer,
       r->'options'
from bk, jsonb_array_elements(bk.j->'tables'->'order_items') r;

-- ---------------- payments ----------------
with bk as (select pg_read_file(:'backup_file')::jsonb as j)
insert into public.payments(id, order_id, method, amount, trx_id, status, verified_by, verified_at, note, created_at)
select coalesce(nullif(r->>'id','')::uuid, gen_random_uuid()),
       (r->>'order_id')::uuid, (r->>'method')::payment_method,
       (r->>'amount')::integer, nullif(r->>'trx_id',''),
       (r->>'status')::payment_status,
       nullif(r->>'verified_by','')::uuid,
       (r->>'verified_at')::timestamptz,
       r->>'note',
       coalesce((r->>'created_at')::timestamptz, now())
from bk, jsonb_array_elements(coalesce(bk.j->'tables'->'payments', '[]'::jsonb)) r;

-- ---------------- order_events ----------------
with bk as (select pg_read_file(:'backup_file')::jsonb as j)
insert into public.order_events(order_id, from_status, to_status, actor, note, created_at)
select (r->>'order_id')::uuid,
       nullif(r->>'from_status','')::order_status,
       (r->>'to_status')::order_status,
       nullif(r->>'actor','')::uuid,
       r->>'note',
       coalesce((r->>'created_at')::timestamptz, now())
from bk, jsonb_array_elements(coalesce(bk.j->'tables'->'order_events', '[]'::jsonb)) r;

-- ---------------- order_files (মেটাডেটা) ----------------
with bk as (select pg_read_file(:'backup_file')::jsonb as j)
insert into public.order_files(id, order_id, file_path, original_name, mime, size_bytes, kind, uploaded_at)
select coalesce(nullif(r->>'id','')::uuid, gen_random_uuid()),
       (r->>'order_id')::uuid, r->>'file_path',
       coalesce(r->>'original_name','file'), (r->>'mime'),
       (r->>'size_bytes')::integer, coalesce(r->>'kind','source'),
       coalesce((r->>'uploaded_at')::timestamptz, now())
from bk, jsonb_array_elements(coalesce(bk.j->'tables'->'order_files', '[]'::jsonb)) r;

-- ---------------- design_proofs ----------------
with bk as (select pg_read_file(:'backup_file')::jsonb as j)
insert into public.design_proofs(id, order_id, round, file_path, status, customer_note, sent_at, responded_at)
select coalesce(nullif(r->>'id','')::uuid, gen_random_uuid()),
       (r->>'order_id')::uuid, (r->>'round')::integer,
       r->>'file_path', (r->>'status')::proof_status,
       r->>'customer_note',
       coalesce((r->>'sent_at')::timestamptz, now()),
       (r->>'responded_at')::timestamptz
from bk, jsonb_array_elements(coalesce(bk.j->'tables'->'design_proofs', '[]'::jsonb)) r;

-- ---------------- ভেরিফাই (লেনদেন খুলে পড়ে) ----------------
drop table _backup_src;
select (select count(*) from public.orders)       as orders,
       (select count(*) from public.order_items)  as order_items,
       (select count(*) from public.payments)     as payments,
       (select count(*) from public.order_events) as order_events,
       (select count(*) from public.order_files)  as order_files,
       (select count(*) from public.design_proofs) as design_proofs;

commit;
