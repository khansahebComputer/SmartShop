#!/usr/bin/env python3
"""
সেবাঘর — backup JSON → INSERT SQL (hosted Supabase SQL editor path)

ব্যবহার:
  python3 tools/backup-to-sql.py shebaghor-backup-YYYY-MM-DD.json > restore.sql

তারপর: Supabase Dashboard → SQL Editor → restore.sql paste → Run.
সতর্কতা: এটি orders পরিবারের সব সারি মুছে backup দিয়ে প্রতিস্থাপন করে।
         services / shop_settings / profiles স্পর্শ করে না।
pg_read_file যায় না hosted Supabase-এ — তাই local tools/restore-backup.sql
পড়তে না পারলে এই পথটি ব্যবহার করুন।
"""
import json, sys, re

UUID_RE = re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

def sql_literal(v, jsonb=False):
    if v is None:
        return 'NULL'
    if isinstance(v, bool):
        return 'TRUE' if v else 'FALSE'
    if isinstance(v, (int, float)):
        return repr(v)
    if jsonb:
        return "'" + json.dumps(v, ensure_ascii=False).replace("'", "''") + "'::jsonb"
    return "'" + str(v).replace("'", "''") + "'"

def main():
    if len(sys.argv) != 2:
        sys.exit('ব্যবহার: python3 tools/backup-to-sql.py shebaghor-backup-YYYY-MM-DD.json > restore.sql')
    path = sys.argv[1]
    try:
        b = json.load(open(path, encoding='utf8'))
    except Exception as e:
        sys.exit(f'backup JSON পড়তে/পার্স করতে সমস্যা: {e} — ফাইলটি corrupted? (কোনো SQL উৎপন্ন হয়নি)')
    if not isinstance(b, dict):
        sys.exit('backup JSON অবজেক্ট নয় — (কোনো SQL উৎপন্ন হয়নি)')
    t = b.get('tables')
    if not isinstance(t, dict):
        sys.exit('backup JSON-এ tables অবজেক্ট নেই — এটি admin.html থেকে নেওয়া ব্যাকআপ নয়? (কোনো SQL উৎপন্ন হয়নি)')
    for k in ['orders', 'order_items']:
        if not isinstance(t.get(k), list):
            sys.exit(f'backup JSON-এ tables.{k} অ্যারে নেই — ফাইলটি corrupted বা পুরনো ভার্সনের। অর্ডার {"আইটেম ছাড়া রিস্টোর হবে!" if k == "order_items" else "অসম্পূর্ণ থাকবে!"} (কোনো SQL উৎপন্ন হয়নি)')
    for k in ['payments', 'order_events', 'order_files', 'design_proofs']:
        v = t.get(k, [])
        if v is not None and not isinstance(v, list):
            sys.exit(f'backup JSON-এ tables.{k} অ্যারে নয় — (কোনো SQL উৎপন্ন হয়নি)')

    print('-- সেবাঘর restore — generated from', path)
    print('-- exported_at:', b.get('exported_at', '?'), '| version:', b.get('version', 1))
    print('BEGIN;')
    for tbl in ['design_proofs', 'order_events', 'order_files', 'order_items', 'payments', 'orders']:
        print(f'delete from public.{tbl};')

    def insert(table, rows, cols, jsonb_cols=(), casts=(), defaults=None):
        if not rows:
            return
        casts = dict(casts); defaults = dict(defaults or {})
        print(f'insert into public.{table}({", ".join(cols)}) values')
        vals = []
        for r in rows:
            out = []
            for c in cols:
                v = r.get(c, defaults.get(c))
                lit = sql_literal(v, c in jsonb_cols)
                out.append(f'{lit}{casts.get(c, "")}')
            vals.append('  (' + ', '.join(out) + ')')
        print(',\n'.join(vals) + ';')

    print()
    insert('orders', t['orders'],
           ['id','order_date','token','status','subtotal','discount','total','paid','payment_method','payment_status','pickup_slot','notes','rework','guest_name','guest_phone','customer_id','created_by','created_at','updated_at'],
           casts={'id':'::uuid','order_date':'::date','status':'::order_status','payment_method':'::payment_method','payment_status':'::payment_status','customer_id':'::uuid','created_by':'::uuid','created_at':'::timestamptz','updated_at':'::timestamptz'},
           defaults={'discount':0,'paid':0,'rework':False})
    print()
    # service_id: keep the link only if the target project has that service
    # (fresh re-seeds use deterministic ids from mid-Nov 2026, so links survive;
    #  older projects degrade to NULL — the item snapshot keeps name/price).
    svc_guard = ("case when exists (select 1 from public.services s "
                 "where s.id = nullif('{v}','')::uuid) then '{v}'::uuid else null end")
    items = []
    for r in t['order_items']:
        v = r.get('service_id')
        r = dict(r)
        if v and UUID_RE.match(str(v)):
            r['service_id'] = svc_guard.format(v=str(v).lower())
        else:
            # absent or malformed service_id -> NULL (item snapshot keeps name/price); never interpolate raw
            r['service_id'] = 'NULL'
        items.append(r)
    print()
    print('insert into public.order_items(id, order_id, service_id, name_snapshot, unit_snapshot, qty, unit_price, options) values')
    vals = []
    for r in items:
        opt = "'" + json.dumps(r['options'], ensure_ascii=False).replace("'", "''") + "'::jsonb" if r.get('options') is not None else 'NULL'
        vals.append("  (%s::uuid, %s::uuid, %s, %s, %s, %s, %s, %s)" % (
            sql_literal(r.get('id')), sql_literal(r.get('order_id')),
            r['service_id'] if r['service_id'] != 'NULL::uuid' else 'NULL',
            sql_literal(r.get('name_snapshot')), sql_literal(r.get('unit_snapshot')),
            sql_literal(r.get('qty')), sql_literal(r.get('unit_price')), opt))
    if vals:
        print(',\n'.join(vals) + ';')
    print()
    insert('payments', t.get('payments', []),
           ['id','order_id','method','amount','trx_id','status','verified_by','verified_at','note','created_at'],
           casts={'id':'::uuid','order_id':'::uuid','method':'::payment_method','status':'::payment_status','verified_by':'::uuid','verified_at':'::timestamptz','created_at':'::timestamptz'})
    print()
    insert('order_events', t.get('order_events', []),
           ['order_id','from_status','to_status','actor','note','created_at'],
           casts={'order_id':'::uuid','from_status':'::order_status','to_status':'::order_status','actor':'::uuid','created_at':'::timestamptz'})
    print()
    insert('order_files', t.get('order_files', []),
           ['id','order_id','file_path','original_name','mime','size_bytes','kind','uploaded_at'],
           casts={'id':'::uuid','order_id':'::uuid','uploaded_at':'::timestamptz'},
           defaults={'size_bytes':1,'kind':'source','original_name':'file'})
    print()
    insert('design_proofs', t.get('design_proofs', []),
           ['id','order_id','round','file_path','status','customer_note','sent_at','responded_at'],
           casts={'id':'::uuid','order_id':'::uuid','status':'::proof_status','sent_at':'::timestamptz','responded_at':'::timestamptz'})
    print('COMMIT;')
    counts = {k: len(v or []) for k, v in t.items()}
    print('-- rows restored:', counts)

if __name__ == '__main__':
    main()
