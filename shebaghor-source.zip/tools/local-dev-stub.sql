-- ============================================================================
-- সেবাঘর — লোকাল উন্নয়ন/ভেরিফিকেশন স্টব (PG17)
-- **কেবল লোকাল PG-তে** — বাস্তব Supabase প্রোজেক্টে auth.* ও storage.* আগে থেকেই আছে।
-- ব্যবহার (scratch DB-তে, ~নতুন প্রজেক্ট সিমুলেশন):
--   psql -d scratch -f tools/local-dev-stub.sql   -- 1) স্কিমা/টেবিল/ফাংশন সেটআপ
--   psql -d scratch -f supabase/schema.sql        -- 2) পাবলিক স্কিমা
--   psql -d scratch -f tools/local-dev-stub.sql   -- 3) আবার — handle_new_user পেলে ট্রিগার যুক্ত
--   psql -d scratch -f supabase/policies.sql      -- 4) RLS + storage policies
--   psql -d scratch -f supabase/seed.sql          -- 5) ২৬টি সেবা
--   psql -d scratch -f supabase/tests.sql         -- 6) A1..A9/D/E/F টেস্ট
-- ধাপ ১ ও ৩ idempotent (if not exists / create or replace) — দুইবার চালানো নিরাপদ।
-- ============================================================================

create schema if not exists auth;
create schema if not exists storage;

-- ---------- auth.users (মিনিমাল স্টব) ----------
create table if not exists auth.users (
  id uuid primary key default gen_random_uuid(),
  email text,
  raw_user_meta_data jsonb not null default '{}'::jsonb
);

create or replace function auth.jwt() returns jsonb language sql stable as $$
  select coalesce(nullif(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb) $$;

create or replace function auth.uid() returns uuid language sql stable as $$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;

-- ---------- storage.buckets / storage.objects (মিনিমাল স্টব) ----------
create table if not exists storage.buckets (
  id text primary key,
  name text,
  public boolean not null default false,
  file_size_limit integer,
  allowed_mime_types text[]
);

create table if not exists storage.objects (
  id uuid primary key default gen_random_uuid(),
  bucket_id text,
  name text,
  owner uuid,
  created_at timestamptz default now()
);

create or replace function storage.foldername(name text) returns text[] language sql immutable as $$
  select (string_to_array(name, '/'))[1:cardinality(string_to_array(name, '/')) - 1] $$;

-- ---------- auth.users → profiles ট্রিগার (schema.sql-এ handle_new_user তৈরি হয়) ----------
-- ensure search_path for handle_new_user() (সেট হয় না, তাই নিচে advisory-check)
do $$
begin
  if exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
             where n.nspname = 'public' and p.proname = 'handle_new_user')
     and not exists (select 1 from pg_trigger where tgname = 'on_auth_user_created') then
    execute 'create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user()';
    raise notice 'trigger on_auth_user_created created';
  end if;
end $$;
