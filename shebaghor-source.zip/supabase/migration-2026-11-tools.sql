-- সেবাঘর — migration 2026-11: চাকরি বোর্ড (job_posts) + কাজের কিউ (work_tasks)
-- Idempotent; safe to re-run. Run AFTER schema.sql / policies.sql.

-- ============ job_posts (shop-hosted notice board; seekers apply via WhatsApp) ============
create table if not exists public.job_posts (
  id             uuid primary key default gen_random_uuid(),
  title_bn       text not null check (length(title_bn) between 3 and 200),
  company        text not null default 'সেবাঘর' check (length(company) between 1 and 200),
  category       text not null default 'other' check (category in ('govt','private','factory','shop','driver','computer','tailoring','other')),
  job_type       text not null default 'full_time' check (job_type in ('full_time','part_time','contract','temporary')),
  location_bn    text,
  salary_bn      text,
  description_bn text not null check (length(description_bn) between 10 and 4000),
  requirements_bn text,
  whatsapp       text not null check (whatsapp ~ '^01[3-9][0-9]{8}$'),
  deadline       date,
  active         boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists idx_job_posts_active on public.job_posts (active, created_at desc);
drop trigger if exists trg_job_posts_updated_at on public.job_posts;
create trigger trg_job_posts_updated_at before update on public.job_posts
  for each row execute function public.set_updated_at();

alter table public.job_posts enable row level security;
drop policy if exists job_posts_select_public on public.job_posts;
create policy job_posts_select_public on public.job_posts for select
  using (active = true or public.is_admin());
drop policy if exists job_posts_admin_all on public.job_posts;
create policy job_posts_admin_all on public.job_posts for all
  using (public.is_admin()) with check (public.is_admin());
grant select on public.job_posts to anon, authenticated;
grant insert, update, delete on public.job_posts to authenticated;

-- ============ work_tasks (admin work queue — কোথায় কোন কাজ) ============
create table if not exists public.work_tasks (
  id            uuid primary key default gen_random_uuid(),
  title_bn      text not null check (length(title_bn) between 2 and 300),
  customer_name text,
  customer_phone text,
  service_hint  text,
  status        text not null default 'queued' check (status in ('queued','in_progress','waiting_customer','ready','done','cancelled')),
  priority      integer not null default 2 check (priority in (1,2,3)),  -- 1=জরুরি, 2=সাধারণ, 3=পরে
  due_date      date,
  notes         text,
  order_id      uuid references public.orders(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_work_tasks_status on public.work_tasks (status, priority, due_date);
create index if not exists idx_work_tasks_order  on public.work_tasks (order_id);
drop trigger if exists trg_work_tasks_updated_at on public.work_tasks;
create trigger trg_work_tasks_updated_at before update on public.work_tasks
  for each row execute function public.set_updated_at();

alter table public.work_tasks enable row level security;
drop policy if exists work_tasks_admin_all on public.work_tasks;
create policy work_tasks_admin_all on public.work_tasks for all
  using (public.is_admin()) with check (public.is_admin());
grant select, insert, update, delete on public.work_tasks to authenticated;
