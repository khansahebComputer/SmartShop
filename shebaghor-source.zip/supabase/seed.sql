-- সেবাঘর (Shebaghor) — supabase/seed.sql  (run AFTER schema.sql + policies.sql)
-- Current shop rate card (2026-11, from দলিল সহায়ক). Admin-editable later via /admin/services.
-- Deterministic service ids: uuid5(DNS 'shebaghor.services', slug) — backups restore with service links intact on fresh projects.
-- requires_file governs the wizard's "must upload" gate:
--   true  → print/photo/pdf-to-word/typing/file-send (customer's own paper or file needed)
--   false → walk-in/assisted services (customer comes with paper or details)
-- Deviation note vs docs/05_Schema §8: deed = false (assisted, in-person draft — customer brings papers);
-- docs' "default true for deed" is the column default, per-service values win.

insert into public.services
  (id, slug, name_bn, description_bn, category, unit_bn, base_price, requires_file, eta_bn, sort_order)
values
  ('ebc7c1cc-fed6-5e84-ae13-92f9223a35a5', 'bw-print',        'B&W প্রিন্ট',                 'সাধারণ কালো-সাদা ডকুমেন্ট প্রিন্ট',        'print',     'পেজ',   3,   true,  '১ ঘণ্টা',          10),
  ('4c449aed-059e-552d-a695-f33801c1ee59', 'color-print',     'রঙিন প্রিন্ট',                'Full color document print (A4)',          'print',     'পেজ',   10,  true,  '১ ঘণ্টা',          20),
  ('f4415757-d35c-5775-8f46-7f449517c139', 'photocopy',       'ফটোকপি',                      'A4 B&W কপি, দুপাশেরও সম্ভব',              'photocopy', 'কপি',   2,   true,  'তাৎক্ষণিক',        30),
  ('c71209da-6ddf-5042-8aa4-4ec0852f85ce', 'scan',            'স্ক্যান + PDF',                'কাগজ থেকে স্পষ্ট PDF তৈরি',               'scan',      'পেজ',   15,  false, 'তাৎক্ষণিক',        40),
  ('4ceabf6d-2a38-5b29-8df2-55711244b8f4', 'pdf-to-word',     'PDF → ওয়ার্ড কনভার্ট',        'PDF থেকে এডিটেবল Word ফাইল',              'typing',    'পেজ',   20,  true,  '২৪ ঘণ্টার মধ্যে',  50),
  ('330c1ae0-94e9-505f-a953-4e4818476089', 'typing-bn',       'বাংলা টাইপিং',                'হাতে লেখা/প্রিন্ট কপি থেকে টাইপ',          'typing',    'পেজ',   40,  true,  '২৪ ঘণ্টার মধ্যে',  60),
  ('1e4d19f3-64fd-57aa-89cc-d1f0ac81c72c', 'typing-en',       'ইংরেজি টাইপিং',               'English typing, any subject',             'typing',    'পেজ',   30,  true,  '২৪ ঘণ্টার মধ্যে',  70),
  ('aa188051-43ce-5ade-8e77-1bb49b779a92', 'cv',              'CV / রেজিউমে প্রস্তুতি',       'প্রফেশনাল CV ডিজাইন সহ',                  'typing',    'ফিক্সড', 150, false, '২৪ ঘণ্টার মধ্যে',  80),
  ('3ed6e056-daa4-5a79-b0b6-57e88b6d73af', 'laminate-a4',     'লেমিনেটিং (A4)',              'A4 সাইজ লেমিনেশন পকেট সহ',                'other',     'পিস',   40,  false, 'তাৎক্ষণিক',        90),
  ('25c711f5-c53a-5e59-aae0-cff9b98e7a8f', 'laminate-card',   'লেমিনেটিং (কার্ড সাইজ)',      'কার্ড/সদস্য কার্ড লেমিনেশন',              'other',     'পিস',   20,  false, 'তাৎক্ষণিক',        100),
  ('83d5b633-19dd-5b88-ba8f-26a6e14c6efd', 'spiral',          'স্পাইরাল বাইন্ডিং',            'প্রজেক্ট/থিসিস স্পাইরাল বাইন্ড',          'other',     'কপি',   60,  false, 'তাৎক্ষণিক',        110),
  ('754b8c2c-7baf-5582-beac-c6e64dda0541', 'hardbind',        'হার্ড বাইন্ডিং',               'থিসিস/স্মরণিকা হার্ড কভার বাইন্ড',        'other',     'কপি',   150, false, '২–৩ দিন',         120),
  ('b02b265c-1b7d-5676-b769-411cf5d2ff20', 'photo-passport',  'পাসপোর্ট সাইজ ছবি',            'সীমান্তবিহীন ছবি প্রিন্ট-কাট',            'photo',     'কপি',   20,  true,  'তাৎক্ষণিক',        130),
  ('7856c788-7944-56ab-a3dc-90e0a87650e5', 'photo-visa',      'ভিসা সাইজ ছবি',               'ভিসা স্পেসিফিকেশন অনুযায়ী ছবি',          'photo',     'কপি',   25,  true,  'তাৎক্ষণিক',        140),
  ('05ae725a-b103-5a5b-97de-ea395bb3545a', 'visiting-card',   'ভিজিটিং কার্ড',                'নাম-কার্ড ডিজাইন + প্রিন্ট',              'design',    'পিস',   6,   false, '২৪ ঘণ্টার মধ্যে',  150),
  ('2a63c2e6-d351-5b99-b7a4-61bc83dede59', 'wedding-card',    'বিয়ের কার্ড ডিজাইন',          'বিয়ের আমন্ত্রণ কার্ড ডিজাইন',            'design',    'পিস',   30,  false, '২–৩ দিন',         160),
  ('d6c149d6-3757-5647-a752-76164c4844a3', 'online-form',     'অনলাইন আবেদন ফিলআপ',           'চাকরি/অ্যাডমিশন/অন্যান্য ফর্ম পূরণ',      'online',    'পেজ',   100, false, '২৪ ঘণ্টার মধ্যে',  170),
  ('d51f06bc-ebe6-55c1-b696-59d43b060a0f', 'deed',            'দলিল প্রস্তুতি (খসড়া)',       'দলিল সহায়ক টুলে খসড়া — সচরাচর দোকানে আসেন', 'deed', 'ফিক্সড', 200, false, 'দোকানে আসুন',     180),
  ('d98c305c-2210-50d2-a2e4-4bb50ec8ed84', 'birth-reg',       'জন্ম নিবন্ধন আবেদন',           'BRIS-এ জন্ম নিবন্ধন অনলাইন আবেদন',         'online',    'ফিক্সড', 150, false, '১–৩ দিন',         190),
  ('c11028d7-d319-546c-986b-b31432eb33da', 'nid-fix',         'NID সংশোধন আবেদন',            'জাতীয় পরিচয় সনদে তথ্য সংশোধন',           'online',    'ফিক্সড', 150, false, '১–৩ দিন',         200),
  ('7d157a9d-df45-50fa-a70b-1ba54b73e20b', 'e-tin',           'ই-টিন নিবন্ধন',               'নতুন টিআইএন সার্টিফিকেট',                  'online',    'ফিক্সড', 200, false, '১–২ দিন',         210),
  ('a129ef59-a601-5cad-841b-e9d537e12ed4', 'police-clearance','পুলিশ ক্লিয়ারেন্স আবেদন',      'পুলিশ ক্লিয়ারেন্স সার্টিফিকেট অনলাইন',     'online',    'ফিক্সড', 200, false, '৩–৭ দিন',         220),
  ('1de36307-a1ef-5814-a4a2-8031e6651990', 'passport',        'ই-পাসপোর্ট আবেদন সহায়তা',     'ই-পাসপোর্ট ফর্ম পূরণ + আপলোড',            'online',    'ফিক্সড', 250, false, '২–৫ দিন',         230),
  ('47a904e1-1cad-5c37-bee1-57d023455951', 'e-ticket',        'ই-টিকিট বুকিং',               'বাস/ট্রেন/বিমান টিকিট কাটা',               'online',    'ফিক্সড', 100, false, 'তাৎক্ষণিক',        240),
  ('00a0dd45-c797-57e0-b63d-28cd69f77fb4', 'visa-help',       'ভিসা আবেদন সহযোগিতা',          'VFS/দূতাবাস ফর্ম + ডকুমেন্ট গাইড',        'online',    'ফিক্সড', 500, false, '৩–১০ দিন',        250),
  ('38ed7dde-62d0-5f58-955e-178d661ced61', 'file-send',       'ইমেইল/WhatsApp ফাইল পাঠানো',    'আপনার ফাইল ইমেইল/WhatsApp-এ পাঠিয়ে দেওয়া', 'other',   'ফিক্সড', 20,  true,  'তাৎক্ষণিক',        260)
on conflict (slug) do update set
  name_bn = excluded.name_bn,
  description_bn = excluded.description_bn,
  category = excluded.category,
  unit_bn = excluded.unit_bn,
  base_price = excluded.base_price,
  requires_file = excluded.requires_file,
  eta_bn = excluded.eta_bn,
  sort_order = excluded.sort_order,
  active = true;
