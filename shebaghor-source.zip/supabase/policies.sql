-- সেবাঘর (Shebaghor) — supabase/policies.sql  (run AFTER schema.sql)
-- Row Level Security matrix per docs/05_Schema.md §5. Idempotent.

-- ============ 5. RLS enable ============
alter table public.profiles       enable row level security;
alter table public.services       enable row level security;
alter table public.orders         enable row level security;
alter table public.order_items    enable row level security;
alter table public.order_files    enable row level security;
alter table public.order_events   enable row level security;
alter table public.payments       enable row level security;
alter table public.design_proofs  enable row level security;
alter table public.shop_settings  enable row level security;

-- ============ profiles ============
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles for select
  using (id = auth.uid() or public.is_admin());

-- users update only their own row, and may NOT flip is_admin (column grant excludes it)
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles for update
  using (id = auth.uid())
  with check (id = auth.uid());

-- column privileges: user-writable columns only (service role bypasses)
revoke all on public.profiles from anon, authenticated;
grant  select on public.profiles to authenticated;
grant  update (full_name, phone, address, bn_digits) on public.profiles to authenticated;
grant  select on public.profiles to anon;  -- anon sees nothing (RLS), kept for SDK symmetry

-- ============ services ============
drop policy if exists services_select_active on public.services;
create policy services_select_active on public.services for select
  using (active = true or public.is_admin());

drop policy if exists services_admin_all on public.services;
create policy services_admin_all on public.services for all
  using (public.is_admin()) with check (public.is_admin());

grant select on public.services to anon, authenticated;
grant insert, update, delete on public.services to authenticated;  -- RLS still gates to admins

-- ============ orders ============
-- inserts ONLY via create_order() RPC (security definer) — no client INSERT policy on purpose
drop policy if exists orders_select_own on public.orders;
create policy orders_select_own on public.orders for select
  using (customer_id = auth.uid() or public.is_admin());

drop policy if exists orders_admin_all on public.orders;
create policy orders_admin_all on public.orders for all
  using (public.is_admin()) with check (public.is_admin());

grant select on public.orders to authenticated;   -- anon: no table read; tracking goes via track_order()
grant update (status, rework, notes, discount, paid, customer_id) on public.orders to authenticated;  -- is_admin-gated by RLS (no own-row UPDATE policy → admins only)

-- ============ order_items ============
-- rows written inside create_order() only; clients read via order ownership
drop policy if exists items_select_own on public.order_items;
create policy items_select_own on public.order_items for select
  using (exists (select 1 from public.orders o
                 where o.id = order_items.order_id
                   and (o.customer_id = auth.uid() or public.is_admin())));

drop policy if exists items_admin_all on public.order_items;
create policy items_admin_all on public.order_items for all
  using (public.is_admin()) with check (public.is_admin());

grant select on public.order_items to authenticated;  -- no INSERT/UPDATE/DELETE for clients

-- ============ order_files ============
-- NO client INSERT/UPDATE/DELETE — rows are written inside create_order() (p_files)
drop policy if exists files_select_own on public.order_files;
create policy files_select_own on public.order_files for select
  using (exists (select 1 from public.orders o
                 where o.id = order_files.order_id
                   and (o.customer_id = auth.uid() or public.is_admin())));

drop policy if exists files_admin_all on public.order_files;
create policy files_admin_all on public.order_files for all
  using (public.is_admin()) with check (public.is_admin());

grant select on public.order_files to authenticated;

-- ============ order_events ============
drop policy if exists events_select_own on public.order_events;
create policy events_select_own on public.order_events for select
  using (exists (select 1 from public.orders o
                 where o.id = order_events.order_id
                   and (o.customer_id = auth.uid() or public.is_admin())));

drop policy if exists events_admin_all on public.order_events;
create policy events_admin_all on public.order_events for all
  using (public.is_admin()) with check (public.is_admin());

grant select on public.order_events to authenticated;

-- ============ payments ============
-- customers never write payments directly; rows are created inside create_order() RPC
drop policy if exists payments_select_own on public.payments;
create policy payments_select_own on public.payments for select
  using (exists (select 1 from public.orders o
                 where o.id = payments.order_id
                   and (o.customer_id = auth.uid() or public.is_admin())));

drop policy if exists payments_admin_all on public.payments;
create policy payments_admin_all on public.payments for all
  using (public.is_admin()) with check (public.is_admin());

grant select on public.payments to authenticated;

-- ============ design_proofs ============
drop policy if exists proofs_select_own on public.design_proofs;
create policy proofs_select_own on public.design_proofs for select
  using (exists (select 1 from public.orders o
                 where o.id = design_proofs.order_id
                   and (o.customer_id = auth.uid() or public.is_admin())));

drop policy if exists proofs_admin_all on public.design_proofs;
create policy proofs_admin_all on public.design_proofs for all
  using (public.is_admin()) with check (public.is_admin());

-- customer may answer ONLY the latest 'sent' proof on their own order,
-- and may touch ONLY (status, customer_note, responded_at) — column grants enforce it
drop policy if exists proofs_customer_respond on public.design_proofs;
create policy proofs_customer_respond on public.design_proofs for update
  using (
    exists (select 1 from public.orders o
            where o.id = design_proofs.order_id and o.customer_id = auth.uid())
    and status = 'sent'
    and not exists (select 1 from public.design_proofs p2
                    where p2.order_id = design_proofs.order_id and p2.round > design_proofs.round)
  )
  with check (
    exists (select 1 from public.orders o
            where o.id = design_proofs.order_id and o.customer_id = auth.uid())
    and status in ('approved', 'changes_requested')
  );
grant update (status, customer_note, responded_at) on public.design_proofs to authenticated;
grant select on public.design_proofs to authenticated;

-- ============ shop_settings ============
drop policy if exists settings_select_public on public.shop_settings;
create policy settings_select_public on public.shop_settings for select
  using (true);   -- pay screen needs bKash/Nagad numbers; no secrets in this table

drop policy if exists settings_admin_update on public.shop_settings;
create policy settings_admin_update on public.shop_settings for update
  using (public.is_admin()) with check (public.is_admin());

grant select on public.shop_settings to anon, authenticated;
grant update (shop_name, address_bn, phone, opening_hours_bn,
              bkash_number, bkash_name, nagad_number, nagad_name,
              pickup_slots, receipt_footer_bn, bn_digits) on public.shop_settings to authenticated;  -- is_admin-gated by RLS

-- ============ Storage (storage.objects) ============
-- Path convention: wizard uploads ALWAYS land in order-files/tmp/<uuid>-<name>.
-- File ownership attached inside create_order() via p_files — clients never INSERT order_files.

drop policy if exists order_files_insert_tmp on storage.objects;
create policy order_files_insert_tmp on storage.objects for insert
  with check (bucket_id = 'order-files' and (storage.foldername(name))[1] = 'tmp');

drop policy if exists order_files_read_own on storage.objects;
create policy order_files_read_own on storage.objects for select
  using (bucket_id = 'order-files' and (
     public.is_admin()
     or exists (select 1
                from public.order_files f
                join public.orders o on o.id = f.order_id
                where f.file_path = 'order-files/' || name and o.customer_id = auth.uid())));

drop policy if exists order_files_delete_admin on storage.objects;
create policy order_files_delete_admin on storage.objects for delete
  using (bucket_id = 'order-files' and public.is_admin());

drop policy if exists proofs_write_admin on storage.objects;
create policy proofs_write_admin on storage.objects for insert
  with check (bucket_id = 'proofs' and public.is_admin());

drop policy if exists proofs_read_own on storage.objects;
create policy proofs_read_own on storage.objects for select
  using (bucket_id = 'proofs' and (
     public.is_admin()
     or exists (select 1
                from public.design_proofs p
                join public.orders o on o.id = p.order_id
                where p.file_path = 'proofs/' || name and o.customer_id = auth.uid())));

drop policy if exists assets_read_public on storage.objects;
create policy assets_read_public on storage.objects for select
  using (bucket_id = 'shop-assets');

drop policy if exists assets_write_admin on storage.objects;
create policy assets_write_admin on storage.objects for insert
  with check (bucket_id = 'shop-assets' and public.is_admin());

drop policy if exists assets_update_admin on storage.objects;
create policy assets_update_admin on storage.objects for update
  using (bucket_id = 'shop-assets' and public.is_admin());

-- Bucket creation is dashboard-side or via SQL:
--   insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
--   values ('order-files','order-files', false, 10485760, '{application/pdf,image/jpeg,image/png}'),
--          ('proofs','proofs', false, 10485760, '{image/jpeg,image/png,application/pdf}'),
--          ('shop-assets','shop-assets', true, 5242880, '{image/svg+xml,image/webp,image/jpeg,image/png}')
--   on conflict (id) do nothing;
