-- সেবাঘর (Shebaghor) — supabase/schema.sql
-- Run order: schema.sql → policies.sql → seed.sql
-- Idempotent where practical: create type ... guarded by DO blocks.
-- Mirrors docs/05_Schema.md (v1.3) exactly.

-- ============ 1. Enum types ============
do $$ begin create type order_status as enum ('placed','pending_verification','confirmed','in_progress','ready','completed','cancelled'); exception when duplicate_object then null; end $$;
do $$ begin create type payment_method as enum ('cash_on_pickup','bkash','nagad','rocket','bank','other'); exception when duplicate_object then null; end $$;
do $$ begin create type payment_status as enum ('not_paid','pending','verified','rejected'); exception when duplicate_object then null; end $$;
do $$ begin create type service_category as enum ('print','photocopy','scan','typing','photo','online','design','deed','other'); exception when duplicate_object then null; end $$;
do $$ begin create type proof_status as enum ('none','sent','approved','changes_requested'); exception when duplicate_object then null; end $$;

-- ============ 2. Tables ============

-- 2.1 profiles (1:1 auth.users)
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  phone       text check (phone ~ '^01[3-9][0-9]{8}$' or phone is null),
  address     text,
  bn_digits   boolean not null default true,
  is_admin    boolean not null default false,  -- mirror of JWT app_metadata; writable by service role only
  created_at  timestamptz not null default now()
);
create unique index if not exists profiles_phone_unique on public.profiles (lower(phone)) where phone is not null;
create index if not exists idx_profiles_phone on public.profiles (phone);

-- 2.2 services
create table if not exists public.services (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null unique check (slug ~ '^[a-z0-9-]+$'),
  name_bn         text not null,
  description_bn  text,
  category        service_category not null,
  unit_bn         text not null,
  base_price      integer not null check (base_price >= 0),
  options_schema  jsonb,
  requires_file   boolean not null default false,
  eta_bn          text,
  active          boolean not null default true,
  sort_order      integer not null default 100,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists idx_services_active_sort on public.services (active, sort_order);
create index if not exists idx_services_category on public.services (category);

-- 2.3 orders
create table if not exists public.orders (
  id              uuid primary key default gen_random_uuid(),
  order_date      date not null default current_date,
  token           integer not null,
  customer_id     uuid references public.profiles(id),
  guest_name      text,
  guest_phone     text,
  status          order_status not null default 'placed',
  subtotal        integer not null check (subtotal >= 0),
  discount        integer not null default 0 check (discount between 0 and subtotal),
  total           integer not null check (total = subtotal - discount),
  paid            integer not null default 0 check (paid between 0 and total),
  due             integer generated always as (total - paid) stored,
  payment_method  payment_method not null default 'cash_on_pickup',
  payment_status  payment_status not null default 'not_paid',
  pickup_slot     text,
  notes           text,
  rework          boolean not null default false,
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  check (token > 0),
  check ((customer_id is not null) or (guest_name is not null and guest_phone is not null))
);
create unique index if not exists idx_orders_date_token on public.orders (order_date, token);
create index if not exists idx_orders_status_date on public.orders (status, order_date);
create index if not exists idx_orders_customer on public.orders (customer_id);
create index if not exists idx_orders_guest_phone on public.orders (guest_phone) where guest_phone is not null;

-- 2.4 order_items
create table if not exists public.order_items (
  id             uuid primary key default gen_random_uuid(),
  order_id       uuid not null references public.orders(id) on delete cascade,
  service_id     uuid references public.services(id) on delete set null,
  name_snapshot  text not null,
  unit_snapshot  text not null,
  qty            numeric(10,2) not null check (qty > 0),
  unit_price     integer not null check (unit_price >= 0),
  line_total     integer generated always as (round(qty * unit_price)) stored,
  options        jsonb
);
create index if not exists idx_order_items_order on public.order_items (order_id);

-- 2.5 order_files
create table if not exists public.order_files (
  id             uuid primary key default gen_random_uuid(),
  order_id       uuid not null references public.orders(id) on delete cascade,
  file_path      text not null,
  original_name  text not null,
  mime           text not null check (mime in ('application/pdf','image/jpeg','image/png')),
  size_bytes     integer not null check (size_bytes > 0 and size_bytes <= 10485760),
  kind           text not null default 'source' check (kind in ('source','proof','nid')),
  uploaded_at    timestamptz not null default now()
);
create index if not exists idx_order_files_order on public.order_files (order_id);
create index if not exists idx_order_files_kind on public.order_files (kind);

-- 2.6 order_events (audit log)
create table if not exists public.order_events (
  id           bigint generated always as identity primary key,
  order_id     uuid not null references public.orders(id) on delete cascade,
  from_status  order_status,
  to_status    order_status not null,
  actor        uuid,                 -- auth.uid(); null = system
  note         text,
  created_at   timestamptz not null default now()
);
create index if not exists idx_order_events_order on public.order_events (order_id);

-- 2.7 payments
create table if not exists public.payments (
  id           uuid primary key default gen_random_uuid(),
  order_id     uuid not null references public.orders(id) on delete cascade,
  method       payment_method not null,
  amount       integer not null check (amount > 0),
  trx_id       text,
  status       payment_status not null default 'pending',
  verified_by  uuid references public.profiles(id),
  verified_at  timestamptz,
  note         text,
  created_at   timestamptz not null default now()
);
create index if not exists idx_payments_order on public.payments (order_id);
create unique index if not exists payments_trx_unique on public.payments (trx_id) where trx_id is not null;

-- 2.8 design_proofs (design proof loop)
create table if not exists public.design_proofs (
  id            uuid primary key default gen_random_uuid(),
  order_id      uuid not null references public.orders(id) on delete cascade,
  round         integer not null check (round between 1 and 10),
  file_path     text not null,
  status        proof_status not null default 'sent',
  customer_note text,
  sent_at       timestamptz not null default now(),
  responded_at  timestamptz
);
create index if not exists idx_design_proofs_order on public.design_proofs (order_id, round);

-- 2.9 shop_settings (singleton)
create table if not exists public.shop_settings (
  id                integer primary key check (id = 1),
  shop_name         text not null default 'সেবাঘর — কম্পিউটার ও গ্রাফিক্স',
  address_bn        text,
  phone             text,
  opening_hours_bn  text,
  bkash_number      text,
  bkash_name        text,
  nagad_number      text,
  nagad_name        text,
  pickup_slots      jsonb not null default '["আজ সন্ধ্যা ৬–৮টা","আগামীকাল সকাল","আগামীকাল দুপুর"]'::jsonb,
  receipt_footer_bn text,
  bn_digits         boolean not null default true,
  updated_at        timestamptz not null default now()
);
insert into public.shop_settings (id) values (1) on conflict (id) do nothing;

-- ============ 3. Helper functions & triggers ============

-- updated_at maintenance
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists trg_orders_updated_at on public.orders;
create trigger trg_orders_updated_at before update on public.orders
  for each row execute function public.set_updated_at();
drop trigger if exists trg_services_updated_at on public.services;
create trigger trg_services_updated_at before update on public.services
  for each row execute function public.set_updated_at();

-- new-user → profile bootstrap (reads signup metadata)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (new.id,
          nullif(new.raw_user_meta_data ->> 'full_name', ''),
          nullif(new.raw_user_meta_data ->> 'phone', ''))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- is_admin(): JWT app_metadata.role='admin' OR profiles.is_admin
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin', false)
      or coalesce((select is_admin from public.profiles where id = auth.uid()), false);
$$;

-- ============ 4. RPCs (SECURITY DEFINER — the only write path for customers) ============

-- Create order: server computes prices; returns new order + token
create or replace function public.create_order(
  p_items    jsonb,        -- [{service_id, qty, options}]
  p_customer jsonb,        -- {name, phone, notes, pickup_slot, payment_method} — customer_id NOT accepted; derived from auth.uid()
  p_trx_id   text default null,
  p_files    jsonb default '[]'  -- [{file_path, kind, size_bytes, mime, original_name}] from wizard tmp/ uploads; inserted as order_files inside this RPC
) returns table(order_id uuid, token int, total int)
language plpgsql security definer set search_path = public as $$
declare
  v_order uuid; v_token int; v_subtotal int := 0; v_line int; v_svc record; v_item jsonb;
begin
  if jsonb_array_length(coalesce(p_items, '[]'::jsonb)) = 0 then
    raise exception 'empty_order';
  end if;
  -- guest orders require name+phone (friendly error instead of 23514)
  if auth.uid() is null and (nullif(p_customer->>'name','') is null or nullif(p_customer->>'phone','') is null) then
    raise exception 'guest_info_required';
  end if;
  -- validate & price server-side (NEVER trust client totals)
  for v_item in select * from jsonb_array_elements(p_items) loop
    select * into v_svc from public.services where id = (v_item->>'service_id')::uuid and active limit 1;
    if not found then raise exception 'service_unavailable:%', v_item->>'service_id'; end if;
    if coalesce((v_item->>'qty')::numeric, 0) <= 0 or (v_item->>'qty')::numeric > 9999 then raise exception 'qty_invalid'; end if;
    v_line := round((v_item->>'qty')::numeric * v_svc.base_price);
    v_subtotal := v_subtotal + v_line;
  end loop;
  -- TrxID format (if paid upfront): 8–12 uppercase alphanumerics
  if p_trx_id is not null and p_trx_id !~ '^[A-Z0-9]{8,12}$' then raise exception 'trx_invalid'; end if;
  -- every file must live under the tmp/ prefix (prevents claiming someone else's object)
  if exists (
    select 1 from jsonb_array_elements(coalesce(p_files, '[]'::jsonb)) f
    where (f->>'file_path') !~ '^order-files/tmp/[A-Za-z0-9._-]+$'
       or coalesce(f->>'mime','') not in ('application/pdf','image/jpeg','image/png')
       or coalesce(nullif(f->>'size_bytes','')::integer, 0) <= 0
       or coalesce(nullif(f->>'size_bytes','')::integer, 0) > 10485760
       or coalesce(f->>'kind','source') not in ('source','nid')
  ) then raise exception 'files_invalid'; end if;
  -- daily token (advisory lock kills the read-max-then-insert race)
  perform pg_advisory_xact_lock(hashtext(current_date::text));
  select coalesce(max(o.token), 0) + 1 into v_token from public.orders o where o.order_date = current_date;
  insert into public.orders(order_date, token, customer_id, guest_name, guest_phone,
                     subtotal, total, payment_method, payment_status, pickup_slot, notes, status)
  values (current_date, v_token,
          auth.uid(),  -- caller; NEVER trust a client-supplied customer_id
          case when auth.uid() is null then nullif(p_customer->>'name','') end,
          case when auth.uid() is null then nullif(p_customer->>'phone','') end,
          v_subtotal, v_subtotal,
          coalesce(nullif(p_customer->>'payment_method','')::payment_method, 'cash_on_pickup'),
          case when p_trx_id is not null then 'pending'::payment_status else 'not_paid'::payment_status end,
          p_customer->>'pickup_slot', p_customer->>'notes',
          case when p_trx_id is not null then 'pending_verification'::order_status else 'placed'::order_status end)
  returning id into v_order;
  -- items snapshot
  insert into public.order_items(order_id, service_id, name_snapshot, unit_snapshot, qty, unit_price, options)
  select v_order, s.id, s.name_bn, s.unit_bn,
         (i->>'qty')::numeric, s.base_price, i->'options'
  from jsonb_array_elements(p_items) i
  join public.services s on s.id = (i->>'service_id')::uuid;
  -- attach wizard-uploaded files (rows written here so guests never need client INSERT on order_files)
  insert into public.order_files(order_id, kind, file_path, size_bytes, mime, original_name)
  select v_order, coalesce(f->>'kind','source'), f->>'file_path',
         nullif(f->>'size_bytes','')::integer, f->>'mime',
         coalesce(nullif(f->>'original_name',''),'file')
  from jsonb_array_elements(coalesce(p_files, '[]'::jsonb)) f;
  if p_trx_id is not null then
    insert into public.payments(order_id, method, amount, trx_id, status)
    values (v_order,
            coalesce(nullif(p_customer->>'payment_method','')::payment_method, 'bkash'),
            v_subtotal, p_trx_id, 'pending');
  end if;
  insert into public.order_events(order_id, from_status, to_status, actor, note)
  values (v_order, null,
          (case when p_trx_id is not null then 'pending_verification' else 'placed' end)::order_status,
          auth.uid(), 'order created');
  return query select v_order, v_token, v_subtotal;
end $$;

-- Guest tracking: token + phone → minimal row, no PII leakage
create or replace function public.track_order(p_token int, p_phone text)
returns table(order_id uuid, token int, status order_status, total int, paid int, due int, items jsonb, events jsonb, pickup_slot text)
language sql security definer set search_path = public as $$
  select o.id, o.token, o.status, o.total, o.paid, o.due,
         (select coalesce(jsonb_agg(jsonb_build_object('name', i.name_snapshot, 'qty', i.qty, 'total', i.line_total)), '[]'::jsonb)
            from public.order_items i where i.order_id = o.id),
         (select coalesce(jsonb_agg(jsonb_build_object('to', e.to_status, 'at', e.created_at) order by e.created_at), '[]'::jsonb)
            from public.order_events e where e.order_id = o.id),
         o.pickup_slot
  from public.orders o
  where o.token = p_token and o.order_date = current_date
    and regexp_replace(coalesce(o.guest_phone, (select phone from public.profiles where id = o.customer_id)), '\D', '', 'g')
      = regexp_replace(p_phone, '\D', '', 'g');
$$;

-- Admin-only status advance with transition guard
create or replace function public.advance_order_status(p_order_id uuid, p_to order_status, p_note text default null)
returns public.orders language plpgsql security definer set search_path = public as $$
declare v_from order_status; v_row public.orders;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select status into v_from from public.orders where id = p_order_id for update;
  if not found then raise exception 'order_not_found'; end if;
  -- allowed transitions matrix (mirror docs/02_AppFlow.md)
  if not (
    (v_from = 'placed'               and p_to in ('confirmed','cancelled')) or
    (v_from = 'pending_verification' and p_to in ('confirmed','cancelled')) or
    (v_from = 'confirmed'            and p_to in ('in_progress','cancelled')) or
    (v_from = 'in_progress'          and p_to = 'ready') or
    (v_from = 'ready'                and p_to = 'completed')
  ) then raise exception 'invalid_transition:%→%', v_from, p_to; end if;
  update public.orders set status = p_to where id = p_order_id
    returning * into v_row;
  insert into public.order_events(order_id, from_status, to_status, actor, note)
  values (p_order_id, v_from, p_to, auth.uid(), p_note);
  return v_row;
end $$;

-- Admin: verify / reject payment (reject → cancel from pending_verification, rolls back otherwise)
create or replace function public.set_payment_status(p_payment_id uuid, p_status payment_status, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  update public.payments
     set status = p_status, verified_by = auth.uid(), verified_at = now(), note = p_note
   where id = p_payment_id;
  if not found then raise exception 'payment_not_found'; end if;
  if p_status = 'verified' then
    perform public.advance_order_status((select order_id from public.payments where id = p_payment_id), 'confirmed', 'payment verified');
  elsif p_status = 'rejected' then
    perform public.advance_order_status((select order_id from public.payments where id = p_payment_id), 'cancelled', coalesce(p_note, 'payment rejected'));
  end if;
end $$;

-- Popularity counts per service (non-cancelled orders) — used by the catalog "জনপ্রিয়" sort
create or replace function public.service_popularity()
returns table(service_id uuid, orders bigint)
language sql stable security definer set search_path = public as $$
  select i.service_id, count(*)::bigint
  from public.order_items i
  join public.orders o on o.id = i.order_id and o.status <> 'cancelled'
  where i.service_id is not null
  group by i.service_id;
$$;

-- Explicit grants (Supabase default grants EXECUTE to public; keep as documentation)
grant execute on function public.create_order(jsonb, jsonb, text, jsonb) to anon, authenticated;
grant execute on function public.track_order(int, text) to anon, authenticated;
grant execute on function public.service_popularity() to anon, authenticated;
grant execute on function public.advance_order_status(uuid, order_status, text) to authenticated;
grant execute on function public.set_payment_status(uuid, payment_status, text) to authenticated;
