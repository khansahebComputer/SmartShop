-- সেবাঘর (Shebaghor) — supabase/tests.sql
-- Run in the Supabase SQL editor AFTER schema+policies+seed on a TEST project.
-- Section A runs as-is (superuser context). Section B must be run through the
-- REST API / client SDK with two test users + anon key (SQL editor cannot simulate JWT easily).

-- ============ A. Sanity asserts (SQL editor, as postgres) ============
do $$
declare v_count int;
begin
  select count(*) into v_count from public.services;
  assert v_count = 26, format('expected 26 seeded services, got %s', v_count);
  raise notice 'A1 ok — 26 services seeded';
end $$;

do $$
declare v_pay int;
begin
  -- every ACTIVE service with requires_file must exist with valid price ≥ 0
  assert not exists (select 1 from public.services where active and base_price < 0);
  raise notice 'A2 ok — prices valid';
end $$;

do $$
declare v_due int;
begin
  -- generated column sanity
  execute 'select 1';
  assert exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='orders' and column_name='due' and is_generated='ALWAYS');
  raise notice 'A3 ok — orders.due is generated';
end $$;

do $$
begin
  -- is_admin() must be false outside a request context (no JWT)
  assert public.is_admin() = false;
  raise notice 'A4 ok — is_admin() false without JWT';
end $$;

do $$
declare v_id uuid; v_items jsonb;
begin
  -- create_order as GUEST (auth.uid() is null in SQL editor): must succeed with name+phone,
  -- token must be 1 on a fresh day, totals must equal sum of DB prices.
  select jsonb_build_array(
           jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 5),
           jsonb_build_object('service_id', (select id from public.services where slug='photocopy'), 'qty', 10)
         ) into v_items;
  select order_id into v_id
  from public.create_order(v_items,
    '{"name":"টেস্ট গ্রাহক","phone":"01700000000","pickup_slot":"আজ","payment_method":"cash_on_pickup"}'::jsonb
  );
  -- expected total: 5*3 + 10*2 = 35
  assert exists (select 1 from public.orders where id = v_id and total = 35 and status = 'placed'),
         'order total/status mismatch';
  raise notice 'A5 ok — guest create_order computed ৳35 server-side';
  -- cleanup (test orders table should be empty on an empty project)
  delete from public.orders where id = v_id;
  raise notice 'A6 ok — test order cleaned up';
end $$;

do $$
declare v_items jsonb;
begin
  -- tamper attempt: qty 0 must be rejected
  select jsonb_build_array(
           jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 0)
         ) into v_items;
  begin
    perform public.create_order(v_items, '{"name":"টেস্ট","phone":"01700000000"}'::jsonb);
    assert false, 'qty_invalid was NOT raised';
  exception when raise_exception then
    raise notice 'A7 ok — qty=0 rejected';
  end;
end $$;

do $$
begin
  -- empty order must be rejected
  begin
    perform public.create_order('[]'::jsonb, '{"name":"টেস্ট","phone":"01700000000"}'::jsonb);
    assert false, 'empty_order was NOT raised';
  exception when raise_exception then
    raise notice 'A8 ok — empty order rejected';
  end;
end $$;

do $$
begin
  -- transition guard: placed → ready must be rejected (admin only, but error must be forbidden first without JWT)
  begin
    perform public.advance_order_status('00000000-0000-0000-0000-000000000000'::uuid, 'ready');
    assert false, 'no exception raised';
  exception
    when raise_exception then raise notice 'A9 ok — advance_order_status raised (%)', sqlerrm;
  end;
end $$;

-- ============ B. Two-user RLS leak test — run via client/REST ============
-- 1. Sign up user A and user B (magic link or password).
-- 2. As A: call create_order with 1 item (anon or logged in). Expect success + token.
-- 3. As B: SELECT * FROM orders;            → expect 0 rows.
-- 4. As B: SELECT * FROM order_items;       → expect 0 rows.
-- 5. As B: SELECT * FROM order_files;       → expect 0 rows.
-- 6. As B: call advance_order_status('<A order id>', 'confirmed') → expect 'forbidden'.
-- 7. As guest (anon): call track_order(<token>, '<wrong phone>') → expect 0 rows (same as bad token).
-- 8. As guest: call track_order(<token>, '<correct phone>')      → expect 1 row, no names/phones returned.
-- Record results in docs/06_Plan.md under P1-10 / P4-02 before marking them [x].

-- ============ C. Token boundary ============
-- On a fresh day, first order must get token=1. Two rapid consecutive create_order calls
-- must produce distinct tokens (advisory lock). Verify:
--   select order_date, token from public.orders where order_date = current_date order by token;

-- ============ D. P4-01 tamper suite (server-side guards, added 2026-11-13) ============
do $$
declare v_items jsonb;
begin
  -- qty 10,000 (over the 9,999 ceiling) must be rejected
  select jsonb_build_array(
           jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 10000)
         ) into v_items;
  begin
    perform public.create_order(v_items, '{"name":"টেস্ট","phone":"01700000000"}'::jsonb);
    assert false, 'qty 10000 was NOT rejected';
  exception when raise_exception then
    raise notice 'D1 ok — qty>9999 rejected (%)', sqlerrm;
  end;
end $$;

do $$
declare v_items jsonb;
begin
  -- garbage TrxID (must be 8–12 uppercase alphanumerics) must be rejected
  select jsonb_build_array(
           jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 1)
         ) into v_items;
  begin
    perform public.create_order(v_items, '{"name":"টেস্ট","phone":"01700000000","payment_method":"bkash"}'::jsonb, 'abc');
    assert false, 'trx_invalid was NOT raised';
  exception when raise_exception then
    raise notice 'D2 ok — bad TrxID rejected (%)', sqlerrm;
  end;
end $$;

do $$
declare v_items jsonb; v_files jsonb;
begin
  -- path traversal against the tmp/ prefix must be rejected
  select jsonb_build_array(
           jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 1)
         ) into v_items;
  select jsonb_build_array(
           jsonb_build_object('file_path','order-files/tmp/../proofs/x.pdf','kind','source','size_bytes',1024,'mime','application/pdf','original_name','x.pdf')
         ) into v_files;
  begin
    perform public.create_order(v_items, '{"name":"টেস্ট","phone":"01700000000"}'::jsonb, null, v_files);
    assert false, 'files_invalid was NOT raised (traversal)';
  exception when raise_exception then
    raise notice 'D0 ok — tmp/../ traversal rejected (%)', sqlerrm;
  end;
  -- file path outside order-files/tmp/ must be rejected (claiming someone else's object)
  select jsonb_build_array(
           jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 1)
         ) into v_items;
  select jsonb_build_array(
           jsonb_build_object('file_path','order-files/orders/aaaa.pdf','kind','source','size_bytes',1024,'mime','application/pdf','original_name','secret.pdf')
         ) into v_files;
  begin
    perform public.create_order(v_items, '{"name":"টেস্ট","phone":"01700000000"}'::jsonb, null, v_files);
    assert false, 'files_invalid was NOT raised (foreign path)';
  exception when raise_exception then
    raise notice 'D3 ok — foreign file_path rejected (%)', sqlerrm;
  end;
  -- oversized file (>10MB) must be rejected even if the client lies
  select jsonb_build_array(
           jsonb_build_object('file_path','order-files/tmp/deadbeef-big.pdf','kind','source','size_bytes',11500000,'mime','application/pdf','original_name','big.pdf')
         ) into v_files;
  begin
    perform public.create_order(v_items, '{"name":"টেস্ট","phone":"01700000000"}'::jsonb, null, v_files);
    assert false, 'files_invalid was NOT raised (oversize)';
  exception when raise_exception then
    raise notice 'D4 ok — oversize file rejected (%)', sqlerrm;
  end;
  -- executable mime must be rejected
  select jsonb_build_array(
           jsonb_build_object('file_path','order-files/tmp/deadbeef-e.exe','kind','source','size_bytes',1024,'mime','application/x-msdownload','original_name','e.exe')
         ) into v_files;
  begin
    perform public.create_order(v_items, '{"name":"টেস্ট","phone":"01700000000"}'::jsonb, null, v_files);
    assert false, 'files_invalid was NOT raised (mime)';
  exception when raise_exception then
    raise notice 'D5 ok — .exe mime rejected (%)', sqlerrm;
  end;
end $$;

do $$
declare v_id uuid; v_note constant text := 'x''; drop table orders;-- <script>alert(1)</script>';
begin
  -- SQL-ish / XSS-ish note must round-trip LITERALLY (parameterized RPC, escaped on render)
  select order_id into v_id
  from public.create_order(
    jsonb_build_array(jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 1)),
    jsonb_build_object('name','টেস্ট','phone','01700000000','notes',v_note)::jsonb);
  assert (select notes from public.orders where id = v_id) = v_note, 'notes were mangled';
  raise notice 'D6 ok — hostile note stored literally, orders table intact (% rows)', (select count(*) from public.orders);
  delete from public.orders where id = v_id;
end $$;

-- ============ E. P4-02/P4-03 RLS + transition simulation (roles anon/authenticated) ============
-- Whole section runs inside one transaction that is ROLLED BACK — the test DB keeps no residue.
-- auth.users is a Phase-0 stub; inserting fires handle_new_user() → profiles created automatically
insert into auth.users(id, email, raw_user_meta_data)
values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'p4-a@example.com', '{"full_name":"পরীক্ষা A","phone":"01800000001"}'::jsonb),
       ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'p4-b@example.com', '{"full_name":"পরীক্ষা B","phone":"01800000002"}'::jsonb)
on conflict (id) do nothing;

begin;
set role authenticated;
set request.jwt.claims = '{}';
set request.jwt.claim.sub = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';

do $$
declare v_order uuid; v_token int; v_count int;
begin
  -- E1: user A (logged in, not admin) creates order via RPC
  select order_id, token into v_order, v_token
  from public.create_order(
    jsonb_build_array(jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 2)),
    '{"name":"পরীক্ষা A","phone":"01800000001","payment_method":"cash_on_pickup"}'::jsonb);
  raise notice 'E1 ok — user A order created (token %)', v_token;

  -- E2: A sees own order
  select count(*) into v_count from public.orders where id = v_order;
  assert v_count = 1, 'A cannot see own order';
  raise notice 'E2 ok — owner sees own order';

  -- E3..E5: B cannot see A's order/items/files
  perform set_config('request.jwt.claim.sub', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', false);
  select count(*) into v_count from public.orders where id = v_order;   assert v_count = 0, 'B saw A orders';
  select count(*) into v_count from public.order_items where order_id = v_order; assert v_count = 0, 'B saw items';
  select count(*) into v_count from public.order_files where order_id = v_order; assert v_count = 0, 'B saw files';
  raise notice 'E3–E5 ok — cross-user read leaked 0 rows (orders/items/files)';

  -- E6: B cannot advance A's order (RPC is_admin gate)
  begin
    perform public.advance_order_status(v_order, 'confirmed', null);
    assert false, 'B advanced A order';
  exception when raise_exception then
    raise notice 'E6 ok — non-admin advance forbidden (%)', sqlerrm;
  end;

  -- E7: B cannot INSERT a payment row (no client INSERT grant)
  begin
    insert into public.payments(order_id, method, amount, trx_id, status)
    values (v_order, 'bkash', 100, 'TESTTRXE7', 'pending');
    assert false, 'B inserted payment';
  exception when insufficient_privilege then
    raise notice 'E7 ok — payments INSERT denied for non-admin';
  end;

  -- E8: B cannot INSERT a service (RLS with-check fails)
  begin
    insert into public.services(slug, name_bn, category, unit_bn, base_price)
    values ('p4-e8-x', 'x', 'other', 'কপি', 1);
    assert false, 'B inserted service';
  exception when insufficient_privilege or raise_exception then
    raise notice 'E8 ok — service INSERT blocked (%)', sqlerrm;
  end;

  -- E9: admin claims see everything
  perform set_config('request.jwt.claims', '{"app_metadata":{"role":"admin"}}', false);
  perform set_config('request.jwt.claim.sub', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', false);
  select count(*) into v_count from public.orders where id = v_order;
  assert v_count = 1, 'admin claims cannot see order';
  raise notice 'E9 ok — admin claims see all rows';

  -- E10: transition guard — skip in_progress (placed → confirmed → ready must fail)
  perform public.advance_order_status(v_order, 'confirmed', 'p4 test');
  begin
    perform public.advance_order_status(v_order, 'ready', null);
    assert false, 'skipped transition accepted';
  exception when raise_exception then
    raise notice 'E10 ok — confirmed→ready blocked (%)', sqlerrm;
  end;

  -- E11: full valid path confirmed → in_progress → ready → completed (row lock)
  perform public.advance_order_status(v_order, 'in_progress', null);
  perform public.advance_order_status(v_order, 'ready', null);
  perform public.advance_order_status(v_order, 'completed', null);
  raise notice 'E11 ok — valid transition path works';
end $$;

rollback;  -- no residue in the test DB
reset role;

-- ============ F. P4-02 proofs RLS (superuser-seeded proof; users only read/respond) ============
do $$
declare v_order uuid; v_proof uuid; v_count int;
begin
  select id into v_order from public.orders limit 1;  -- E-section rolled back, so create one
  if v_order is null then
    select order_id into v_order
    from public.create_order(
      jsonb_build_array(jsonb_build_object('service_id', (select id from public.services where slug='bw-print'), 'qty', 1)),
      '{"name":"প্রুফ টেস্ট","phone":"01800000003","payment_method":"cash_on_pickup"}'::jsonb, null, '[]'::jsonb);
    -- guest order: proofs are admin-inserted; customer_id null → nobody can read except admin
  end if;
  insert into public.design_proofs(order_id, round, file_path) values (v_order, 1, 'proofs/test-round1.pdf')
  returning id into v_proof;
  -- anon/auth as B sees 0 rows
  perform set_config('request.jwt.claims', '{}', true);
  perform set_config('request.jwt.claim.sub', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', true);
  set local role authenticated;
  select count(*) into v_count from public.design_proofs where id = v_proof;
  assert v_count = 0, 'B could read admin proof';
  reset role;
  raise notice 'F1 ok — unrelated authenticated user sees 0 proof rows';
  delete from public.design_proofs where id = v_proof;
  delete from public.orders where id = v_order;
end $$;
