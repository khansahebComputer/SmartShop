/* দলিল সহায়ক — Service Worker (অফলাইন চালানোর জন্য)
   GitHub Pages-এ হোস্ট করলে index.html ও অ্যাপের অ্যাসেট ক্যাশ হয়।
   NID OCR-এর Tesseract লাইব্রেরি আলাদা (CDN থেকে আসে, ইন্টারনেট লাগে)। */
const CACHE = 'dolil-sohoyok-v2';
const ASSETS = ['./', './index.html', './manifest.json', './icon.svg'];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', event => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return; // CDN/OCR → নেটওয়ার্কই ব্যবহার করবে
  event.respondWith(
    caches.match(request).then(cached => cached || fetch(request).then(resp => {
      const copy = resp.clone();
      caches.open(CACHE).then(cache => cache.put(request, copy));
      return resp;
    }).catch(() => caches.match('./index.html')))
  );
});
